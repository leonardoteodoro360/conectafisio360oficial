
import React from 'react';
import { 
  Home, 
  BookOpen, 
  Box, 
  Gamepad2, 
  Users, 
  MessageSquare, 
  ShoppingCart, 
  Newspaper, 
  Bell,
  Search,
  UserCircle
} from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 px-4 md:px-8 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
        
        {/* Logo Section */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Box size={24} />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-indigo-900 font-bold text-lg leading-none">ConectaFisio</h1>
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Conectando Saberes</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex items-center gap-1 md:gap-2">
          <NavItem icon={<Home size={18} />} label="Início" active />
          <NavItem icon={<BookOpen size={18} />} label="Cursos" />
          <NavItem icon={<Box size={18} />} label="Modelos 3D" badge="Novo" />
          <NavItem icon={<Gamepad2 size={18} />} label="FisioArena" badge="Novo" />
          <NavItem icon={<Users size={18} />} label="Comunidades" />
          <NavItem icon={<MessageSquare size={18} />} label="Chat" count={3} />
          <NavItem icon={<ShoppingCart size={18} />} label="Loja" />
          <NavItem icon={<Newspaper size={18} />} label="Notícias" count={12} />
        </nav>

        {/* User / Actions */}
        <div className="flex items-center gap-4 flex-shrink-0">
          <button className="p-2 text-slate-400 hover:text-indigo-600 transition-colors relative">
            <Bell size={22} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
          
          <div className="hidden lg:flex items-center gap-3 pl-4 border-l border-slate-100">
            <div className="text-right">
              <p className="text-xs font-bold text-slate-800">Usuário Convidado</p>
              <div className="flex items-center justify-end gap-1">
                <span className="text-[10px] bg-amber-100 text-amber-700 px-1 rounded font-bold">Estudante</span>
                <span className="text-[10px] text-amber-500 font-bold">★ 1</span>
              </div>
            </div>
            <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
              <UserCircle size={28} />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  badge?: string;
  count?: number;
}

const NavItem: React.FC<NavItemProps> = ({ icon, label, active, badge, count }) => {
  return (
    <button className={`
      flex items-center gap-2 px-3 py-2 rounded-xl transition-all relative flex-shrink-0
      ${active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-500 hover:bg-slate-50 hover:text-indigo-600'}
    `}>
      {icon}
      <span className="text-sm font-semibold whitespace-nowrap hidden xl:block">{label}</span>
      
      {badge && (
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-bold px-1 py-0.5 rounded leading-none uppercase">
          {badge}
        </span>
      )}
      
      {count !== undefined && (
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-bold w-4 h-4 flex items-center justify-center rounded-full leading-none">
          {count}
        </span>
      )}
    </button>
  );
};

export default Header;
