
import React from 'react';
import Header from './Header';
import { GraduationCap, Zap, MessageCircle, BarChart3, Star } from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow flex flex-col items-center justify-center px-4 py-12 md:py-24 max-w-7xl mx-auto w-full">
        
        {/* Launch Badge */}
        <div className="mb-8 animate-bounce">
          <div className="bg-white border border-indigo-100 rounded-full px-4 py-1.5 flex items-center gap-2 shadow-sm">
            <Star size={16} className="text-indigo-500 fill-indigo-500" />
            <span className="text-indigo-600 text-xs font-bold tracking-wide uppercase">Plataforma lançamento 2024</span>
          </div>
        </div>

        {/* Hero Section */}
        <div className="text-center space-y-6 max-w-4xl">
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-[#1E293B] tracking-tight leading-tight">
            O ecossistema digital <br />
            <span className="text-indigo-600">da fisioterapia</span>
          </h2>
          
          <p className="text-slate-500 text-lg md:text-xl font-medium leading-relaxed max-w-2xl mx-auto">
            Unindo aprendizado interativo, comunidade engajada e recursos profissionais em uma plataforma completa para fisioterapeutas e estudantes.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-16 w-full max-w-6xl">
          <FeatureCard 
            icon={<GraduationCap size={24} />} 
            title="Continuar Estudando" 
          />
          <FeatureCard 
            icon={<Zap size={24} />} 
            title="Desafio do Dia" 
          />
          <FeatureCard 
            icon={<MessageCircle size={24} />} 
            title="Novas Mensagens" 
          />
          <FeatureCard 
            icon={<BarChart3 size={24} />} 
            title="Meu Progresso" 
          />
        </div>
      </main>

      <footer className="py-8 text-center text-slate-400 text-sm border-t border-slate-100">
        &copy; 2024 ConectaFisio - Todos os direitos reservados.
      </footer>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title }) => {
  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group flex flex-col items-center sm:items-start text-center sm:text-left gap-4">
      <div className="w-12 h-12 rounded-xl bg-slate-50 text-slate-700 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-colors">
        {icon}
      </div>
      <h3 className="font-bold text-slate-800 text-lg leading-tight">
        {title}
      </h3>
    </div>
  );
};

export default LandingPage;
