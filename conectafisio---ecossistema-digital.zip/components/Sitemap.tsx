
import React from 'react';
import { Link } from 'react-router-dom';
import { Map, ArrowRight, ExternalLink } from 'lucide-react';

const Sitemap: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl shadow-slate-200 border border-slate-100 p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
            <Map size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Mapa do Projeto</h1>
            <p className="text-xs text-slate-500 font-medium">Ambiente de Desenvolvimento</p>
          </div>
        </div>

        <div className="space-y-3">
          <SitemapLink 
            to="/lp-video" 
            title="Página Principal (LP)" 
            description="Landing page do ecossistema ConectaFisio"
          />
          <div className="p-4 border border-dashed border-slate-200 rounded-2xl bg-slate-50 opacity-50">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-bold text-slate-400">Próximas Rotas</span>
            </div>
            <p className="text-xs text-slate-400">Novas rotas aparecerão aqui conforme o desenvolvimento avança.</p>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-100">
          <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-4">Informações Técnicas</p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-50 p-2 rounded-lg">
              <span className="block text-slate-400">Router</span>
              <span className="font-bold text-indigo-600">HashRouter</span>
            </div>
            <div className="bg-slate-50 p-2 rounded-lg">
              <span className="block text-slate-400">Vite Base</span>
              <span className="font-bold text-slate-700">./</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface SitemapLinkProps {
  to: string;
  title: string;
  description: string;
}

const SitemapLink: React.FC<SitemapLinkProps> = ({ to, title, description }) => {
  return (
    <Link to={to} className="group block p-4 rounded-2xl border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50 transition-all">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-800 group-hover:text-indigo-700">{title}</h3>
          <p className="text-xs text-slate-500">{description}</p>
        </div>
        <ArrowRight size={18} className="text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
      </div>
    </Link>
  );
};

export default Sitemap;
