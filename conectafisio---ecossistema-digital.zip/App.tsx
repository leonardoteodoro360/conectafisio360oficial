
import React from 'react';
import { BrowserRouter, HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import Sitemap from './components/Sitemap';

/**
 * Detecção de Ambiente:
 * Verifica se estamos rodando em um proxy de desenvolvimento (Google IDX, Stackblitz, etc.)
 */
const checkPreviewEnvironment = (): boolean => {
  const indicators = [
    'googleusercontent',
    'webcontainer',
    'calço',
    '.goog',
    'scf.usercontent',
    'stackblitz',
    'codesandbox'
  ];
  const currentHref = window.location.href.toLowerCase();
  const currentHostname = window.location.hostname.toLowerCase();
  
  return indicators.some(indicator => 
    currentHref.includes(indicator) || currentHostname.includes(indicator)
  );
};

const App: React.FC = () => {
  const isPreview = checkPreviewEnvironment();
  
  // Seleção dinâmica do Roteador (Hybrid Routing)
  const Router = isPreview ? HashRouter : BrowserRouter;

  // Redirecionamento dinâmico para a rota raiz
  const RootRedirect = isPreview ? <Navigate to="/sitemap" replace /> : <Navigate to="/lp-video" replace />;

  return (
    <Router>
      <Routes>
        <Route path="/" element={RootRedirect} />
        <Route path="/sitemap" element={<Sitemap />} />
        <Route path="/lp-video" element={<LandingPage />} />
        {/* Rota de fallback para evitar 404s internos */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

export default App;
